import React from 'react';
import './Vision.css';

export default function Vision() {
    return (
        <div className="vision_news">
         <div className="vision">
            <h1 className="vision_head">Vision</h1>
            <div className="vision_text">
             <p>Working with strong commitment for technology-
                based solutions and driving the society with new
                ideas and innovations</p>
            </div>
        </div>
        <div className="news">
          <h1 className="news_head">News Feed</h1>
          <div className="news-text">
            <h4>&#10031; Join the WhatsApp Group via Invite Link Sent after Registrations</h4>
            <h4>&#10031; Do Follow our Social Media Handles</h4>
            <p><a href="www.instagram.com/sae_nitk">&emsp;- Instagram </a></p>
            <p><a href="www.facebook.com/saenitk">&emsp;- Facebook</a></p>
            <p><a href="www.instagram.com/sae_nitk">&emsp; -LinkedIn </a></p>
            <h4>STAY TUNED!</h4>
            <h4><i>Do Not Miss the oppurtunity!</i></h4>
          </div>
          </div>
          </div>

    )
}

