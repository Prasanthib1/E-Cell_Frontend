import React, {Component} from 'react';
import * as FaIcons from 'react-icons/fa';
import {useState} from 'react';

class SearchBar extends Component{
state={ visible: false}

render(){
    return (
      <div className="Search">
        <span className="SearchSpan">
          <FaIcons.FaSearch onClick={()=>{this.setState=({ visible:false });}}/>
        </span>
        <input
          className="SearchInput"
          type="text"
          onChange={this.inputchangehandler} 
          placeholder={placeholder}
        />
      </div>
    );
}
}

export default SearchBar