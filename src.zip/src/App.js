import './App.css';
import Header from './Header';
import Vision from './Vision';
import Core from './Core';
import Youtube from './Youtube';
import Contact from './Contact';
import {BrowserRouter as Router,Switch,Route}  from 'react-router-dom';
import Blogsmain from './Blogsmain';
import Club from './Club';
import About from './About';
import Magazine from './magazine';
import CarouselCheck from './Event';
import Projects1 from './projects1';
import Home from './home';
import Projects2 from './projects2';
import Event from './Event';
import HPVideo from './hpvideo';
import Alumni from './alumni';
import {Event1_21, Event2_21, Event3_21, Event4_21, Event5_21, Event6_21, Event7_21, Event8_21, Event9_21, Event10_21,Event1_20, Event2_20, Event3_20, Event4_20, Event5_20, Event6_20, Event7_20} from './Events/event_1';
//import { Carousel } from 'bootstrap';

function App() {
  return (
    <Router>
      <Header />
      <Switch>
       <div className="app">
        <Route exact path="/">
          <Home />
          <HPVideo/>
          <Vision />
          <Core />
          <Youtube />         
        </Route>
        <Route exact path="/about">
           <About />
        </Route>
        <Route exact path="/blog">
            <Blogsmain/>
        </Route>
        <Route exact path="/project1">
            <Projects1 />
        </Route>
        <Route exact path="/project2">
            <Projects2 />
            <Magazine />
        </Route>
        <Route exact path="/club">
           <Club />
        </Route>
        <Route exact path="/alumni">
             <Alumni/>
        </Route>
        <Route exact path="/event">
          <Event />
        </Route>
        <Route exact path="/event1_21"><Event1_21/></Route>
        <Route exact path="/event2_21"><Event2_21/></Route>
        <Route exact path="/event3_21"><Event3_21/></Route>
        <Route exact path="/event4_21"><Event4_21/></Route>
        <Route exact path="/event5_21"><Event5_21/></Route>
        <Route exact path="/event6_21"><Event6_21/></Route>
        <Route exact path="/event7_21"><Event7_21/></Route>
        <Route exact path="/event8_21"><Event8_21/></Route>
        <Route exact path="/event9_21"><Event9_21/></Route>
        <Route exact path="/event10_21"><Event10_21/></Route>
        <Route exact path="/event1_20"><Event1_20/></Route>
        <Route exact path="/event2_20"><Event2_20/></Route>
        <Route exact path="/event3_20"><Event3_20/></Route>
        <Route exact path="/event4_20"><Event4_20/></Route>
        <Route exact path="/event5_20"><Event5_20/></Route>
        <Route exact path="/event6_20"><Event6_20/></Route>
        <Route exact path="/event7_20"><Event7_20/></Route>
        </div>
      </Switch>
      <Contact />
    </Router>
  );
}

export default App;

