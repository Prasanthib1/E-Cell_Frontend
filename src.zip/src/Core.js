
import React from 'react';
import './Core.css';
import MemberImage from './components/MemberImage';
import img from './images/profile.jpg';

import img1 from './images/K-Eshwar.jpg';
import img2 from './images/Ankit-Gupta.jpg';
import img4 from './images/Diwakar-S-G.jpg';
import img5 from './images/Kaustubh-S.jpg';

function Core() {
    return (
        <div className="core" >
          <div className="heading">
            <h1>Core Team</h1>
          </div>
          <div className="core_members">
           <div className="mem1">
           <MemberImage
            src={img1}
            name="K Eshwar Sai Srinivas"
            role="Convener"
            mail="p@gmail.com"
            lin="#"/>
           <MemberImage
            src={img2}
            name="Ankit Gupta"
            role="President"
            mail="#"
            lin="#"/>
            <MemberImage
            src={img}
            name="Rishu"
            role="Secretary"
            mail="#"
            lin="#" />
            <MemberImage
            src={img4}
            name="Diwaker S Goud"
            role="Technical Lead"
            mail="#"
            lin="#"/>
            <MemberImage
            src={img5}
            name="Kaustubh"
            role="Technical Lead"
            mail="#"
            lin="#"/>
          </div>
          {/*<div className="mem2">

            <MemberImage
            src={img5}
            name="xxx"
            role="xxx"
            mail="#"
            lin="#" />
            <MemberImage
            src={img6}
            name="xxx"
            role="xxx"
            mail="#"
            lin="#" />
           <MemberImage
            src={img7}
            name="Rajat Shukla"
            role="Convener"
            mail="#"
            lin="#"/>

    </div>*/}
          </div>
          
      </div>
    )
}

export default Core
