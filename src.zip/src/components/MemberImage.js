
import React from 'react';
import './MemberImage.css';
import EmailIcon from '@material-ui/icons/Email';
import LinkedInIcon from '@material-ui/icons/LinkedIn';

function MemberImage({src,name,role,mail,lin}) {
    return (
        <div className="member">
            <div className="icon">
              <img src={src} />
            </div>
            <div className="name">
               <h3>{name}</h3>
            </div>
            <div className="role">
               <h3>{role}</h3>
            </div>
            <div className="insta">
               <EmailIcon className="i1"  component="a" href={"mailto:"+ mail} />
               <LinkedInIcon className="i2" onClick={()=> window.open({lin}, "_blank")}/>
            </div>
        </div>
    )
}

export default MemberImage
