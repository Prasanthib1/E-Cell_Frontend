import React from "react";
import './Vision.css';
import Video from "./images/video.mp4";

export default function HPVideo() {
  return (
    <div className="hp-video">
        <video className="hpvideo"
        autostart 
        autoPlay 
        src={Video} 
        type="video/mp4" 
        width="200px"
        height="auto"
        />
      </div>
  );
}