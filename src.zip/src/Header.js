import React from 'react';
import './Header.css';
import {Link} from 'react-router-dom';
import {Dropdown,Button,ButtonGroup} from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import * as AiIcons from 'react-icons/ai';

const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: "smooth"
    });
  };

export default function Header() {
    return (
        <div className="header">
          <ul className="h-navbar">
            <li><Link to="/">
             <img className="header-image" 
                  src="https://saenitk.files.wordpress.com/2020/05/sae-nitk-club-logo-jpg-file-1.png?w=697"
                  height="50px"
                  width="auto" />
                </Link></li>
            <li className="li6"><Link className="page6" to="/event" style={{ textDecoration: 'none' }}>
            <h3 className="header-text">EVENTS</h3>
            </Link></li>

            <li className="li5">
            <Link to="#" className="page5" style={{ textDecoration: 'none' }} >
                <h3 className="header-text">PROJECTS ▼</h3></Link>
            <div class="project-dd">
                <Link className="link-i" to="/project1" style={{ textDecoration: 'none' }}>
                    <p className="link-item">2019-2020</p></Link>
                <Link className="link-i" to="/project2" style={{ textDecoration: 'none' }}>
                    <p className="link-item">2020-2021</p></Link>
            </div>
            </li>

            <li className="li4">
            <Link to ="#" className="page4" style={{ textDecoration: 'none' }}>
                <h3 className="header-text">MEMBERS ▼</h3></Link>
            <div class="club-dd">
                <Link className="link-i" to="/club" style={{ textDecoration: 'none' }}>
                    <p className="link-item">Current Team</p></Link>
                <Link className="link-i" to="/alumni" style={{ textDecoration: 'none' }}>
                    <p className="link-item">Alumni</p></Link>
            </div>
            </li>

            <li className="li3"><Link className="page3" to="/blog" style={{ textDecoration: 'none' }}>
            <h3 className="header-text">BLOGS</h3>
            </Link></li>

            <li className="li2"><Link to="/about" className="page2" style={{ textDecoration: 'none' }}>
            <h3 className="header-text" >ABOUT US</h3>
            </Link></li>

            <li className="li1"><Link to="/" className="page1" style={{ textDecoration: 'none' }}>
            <h3 className="header-text" >HOME</h3>
            </Link></li>
            </ul> 
            <div className="back-to-top" onClick={scrollToTop}><p>Back to top <AiIcons.AiOutlineArrowUp /></p></div>
        </div> 
    )
    }
